//
//  ItemsCollectionViewCell.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/15.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit

class ItemsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var producImage: UIImageView!
    @IBOutlet weak var Description: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var action: UIActivityIndicatorView!
}
