//
//  ReceiptViewController.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/16.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit
import SQLite3

class ReceiptViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var outerView: UIView!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var shareBtn: UIButton!
    
    var receipt = [CartModel]()
    
    var tot = 0.0
    
    var db: OpaquePointer?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //allow to click the darker space to remove the modal
        let gestureSwift2AndHigher = UITapGestureRecognizer(target: self, action:  #selector (self.someAction (_:)))
        self.outerView.addGestureRecognizer(gestureSwift2AndHigher)
        
        // style buttons
        shareBtn.layer.borderColor = UIColor.blue.cgColor
        shareBtn.layer.borderWidth = 2
        shareBtn.layer.cornerRadius = 4
        
        //connect to sqlite database
        let fileUrl = try!
            FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Products.sqlite")
        
        if sqlite3_open(fileUrl.path, &db) != SQLITE_OK {
            print("Error opening database")
            return
        }
        
        
        //get all data in the database
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, "SELECT * FROM fruit", -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing select: \(errmsg)")
        }
        
        while sqlite3_step(statement) == SQLITE_ROW {
            let id = sqlite3_column_int64(statement, 0)
            print("id = \(id); ", terminator: "")
            
            var names = ""
            var price = ""
            if let cString = sqlite3_column_text(statement, 2) {
                let name = String(cString: cString)
                
                names = name
                print("name = \(name)")
            } else {
                print("name not found")
            }
            
            if let cString = sqlite3_column_text(statement, 3) {
                let name = String(cString: cString)
                
                tot += Double(name)!

                price = name
                print("name = \(name)")
            } else {
                print("name not found")
            }
            
            receipt.append(CartModel(name: names, price: price))
        }
        
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        
        statement = nil
        
        print("show total \(tot)")
        
        total.text = "R\(tot)"
        
        let formatter = DateFormatter()
        
        formatter.dateFormat = "EEEE dd-MMMM-yyyy HH:mm a"
        let str = formatter.string(from: Date())
        //print(str)
        date.text = str
    }
    

    @IBAction func share(_ sender: Any) {
        let activity = UIActivityViewController(activityItems: ["luyanda"], applicationActivities: nil)
        activity.popoverPresentationController?.sourceView = self.view
        
        self.present(activity,animated: true, completion: nil)
    }
    
    @objc func someAction(_ sender:UITapGestureRecognizer){
        // do other task
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return receipt.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ReceiptCellTableViewCell
        
        
        cell.productName.text = receipt[indexPath.row].name
        cell.quantity.text = "1"
        cell.price.text = "R" + receipt[indexPath.row].price!
        tableView.tableFooterView = UIView()
        return cell
    }
}
