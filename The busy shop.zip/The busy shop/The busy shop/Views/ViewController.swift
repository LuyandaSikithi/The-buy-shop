//
//  ViewController.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/15.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit
import Firebase
import SQLite3

class ViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    
    var refProducts: DatabaseReference!
    var productss = [ProductsModel]()
    var cart = [Cart]()
    
 
    var db: OpaquePointer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Animating the activity while loading data from database
        activity.startAnimating()
        
        //Collection view cell sizes on screan
        let itemSize = UIScreen.main.bounds.width / 2
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        layout.itemSize = CGSize(width: itemSize, height: 200)
        
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        
        collectionView.collectionViewLayout = layout
        
        //get products from firebase, firestore database
        getProducts()
        
        //create sqlite database and fruit table
        sqliteDatabase()
        
        //get all products from sqlite data base and check the id from scanned code if it exist in the database
        getAllProducs()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return productss.count
    }
    //loading images in the back ground
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ItemsCollectionViewCell
       //aminate activity for images in cell
        cell.action.startAnimating()
       
        cell.Description.text = productss[indexPath.row].description
        cell.price.text = "R\(productss[indexPath.row].price!)"
        
        //get images from database storage url and load them in a back ground
        let url = URL(string: "https://firebasestorage.googleapis.com/v0/b/the-busy-shop-4de26.appspot.com/o/\(productss[indexPath.row].image!)?alt=media")!
        getData(from: url) { data, response, error in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() {
                cell.self.producImage.image = UIImage(data: data)
                cell.action.stopAnimating()
                cell.action.isHidden = true
            }
        }
        
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       //show alert when product is clicked to cornfirm purchase
        let alert = UIAlertController(title: "Adding \(productss[indexPath.row].description!) to Cart?"  , message: "Price R\(productss[indexPath.row].price!)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {(action) in
            var stmt: OpaquePointer?
            
            
            let insertQuery = "INSERT INTO fruit (proId, name, price) VALUES (?, ?, ?)"
            
            if sqlite3_prepare(self.db, insertQuery, -1, &stmt, nil) != SQLITE_OK {
                print("Error binding query")
            }
            
            if sqlite3_bind_text(stmt, 1, self.productss[indexPath.row].id, -1, nil) != SQLITE_OK {
                print("Error binding id")
            }
            
            if sqlite3_bind_text(stmt, 2, self.productss[indexPath.row].description, -1, nil) != SQLITE_OK {
                print("Error binding description")
            }
            
            if sqlite3_bind_double(stmt, 3, self.productss[indexPath.row].price!) != SQLITE_OK {
                print("Error binding price")
            }
            
            if sqlite3_step(stmt) == SQLITE_DONE {
                print("Product saved")
            }
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    func getProducts(){
        let dbs = Firestore.firestore()
        dbs.collection("product").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    
                    self.productss.append(ProductsModel(id: document.data()["id"] as? String, description: document.data()["description"] as? String, image: document.data()["image"] as? String, price: document.data()["price"] as? Double))
                
                }
                self.activity.stopAnimating()
                self.activity.isHidden = true
                self.collectionView.reloadData()
               // print(self.productss.count)
            }
        }
    }
    
  
    
    func sqliteDatabase(){
        let fileUrl = try!
            FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Products.sqlite")
        
        if sqlite3_open(fileUrl.path, &db) != SQLITE_OK {
            print("Error opening database")
            return
        }
        //getAllProducs()
        let createTableQuery = "CREATE TABLE IF NOT EXISTS fruit (id INTEGER PRIMARY KEY AUTOINCREMENT, proId TEXT, name TEXT, price, TEXT)"
        
        if sqlite3_exec(db, createTableQuery, nil, nil, nil) != SQLITE_OK {
            print("Error creating table")
            return
        }
        print("everything is fine")
    }
    
    func getAllProducs(){
      //  print(testProd.count)
        //print(UserDefaults.standard.object(forKey: CommonData.CODE)
        
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, "SELECT * FROM fruit", -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing select: \(errmsg)")
        }
        
        while sqlite3_step(statement) == SQLITE_ROW {
            
            var prodIdz = ""
            var price = 0.0
            var description = ""
            
            let id = sqlite3_column_int64(statement, 0)
            print("id = \(id); ", terminator: "")
            
            if let cString = sqlite3_column_text(statement, 1) {
                let name = String(cString: cString)
                print("name = \(name)")
                prodIdz = name
            }else {
                print("name not found")
            }
            
            if let cStrings = sqlite3_column_text(statement, 2) {
                let names = String(cString: cStrings)
                print("name = \(names)")
                description = names
            } else {
                print("name not found")
            }
            if let cStrings = sqlite3_column_text(statement, 32) {
                let namez = String(cString: cStrings)
                let nam = Double(namez)
               // print("name = \(namez)")
                price = nam!
            } else {
                print("name not found")
            }
            
            //check if the scanned code is not nil
            if UserDefaults.standard.object(forKey: CommonData.CODE) as? String == nil{
                print("code is empty")
            }else{
                print("do something with code \(UserDefaults.standard.object(forKey: CommonData.CODE))")
                
                //check if the code exixt inthe sqlite database
                if UserDefaults.standard.object(forKey: CommonData.CODE) as? String == "BAN258" {
                    //if the code exist add quantity
                    print("add quantity")
                    
                }else{
                    //if not existing add to sqlite database
                    var stmt: OpaquePointer?
                    
                    let insertQuery = "INSERT INTO fruit (proId, name, price) VALUES (?, ?, ?)"
                    
                    if sqlite3_prepare(db, insertQuery, -1, &stmt, nil) != SQLITE_OK {
                        print("Error binding query")
                    }
                    
                    if sqlite3_bind_text(stmt, 1, prodIdz, -1, nil) != SQLITE_OK {
                        print("Error binding id")
                    }
                    
                    if sqlite3_bind_text(stmt, 2, description, -1, nil) != SQLITE_OK {
                        print("Error binding description")
                    }
                    
                    if sqlite3_bind_double(stmt, 3, price) != SQLITE_OK {
                        print("Error binding price")
                    }
                    
                    if sqlite3_step(stmt) == SQLITE_DONE {
                        print("Product saved")
                        UserDefaults.standard.set(nil, forKey: CommonData.CODE)
                    }
                    
                }
            }
            
            
        }
        
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        statement = nil
        
    }
    
   
 
}
