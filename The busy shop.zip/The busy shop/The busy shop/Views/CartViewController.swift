//
//  CartViewController.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/15.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit
import SQLite3

class CartViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var confirmBut: UIButton!
    @IBOutlet weak var total: UILabel!
    
    
    var cart = [Cart]()
    var onCart = [ProductsModel]()
    
    var tot = 0.0
    var db: OpaquePointer?
    override func viewDidLoad() {
        super.viewDidLoad()
            //showHere.text = myString
       // let stmt = db.prepare("SELECT id, someDate, someString, someInt FROM myTable")
        //for row in stmt {
            // [Optional(1), Optional("2014-10-30"), Optional("Hello!"), Optional(5)]
       // }
        
        confirmBut.layer.borderColor = UIColor.blue.cgColor
        confirmBut.layer.borderWidth = 2
        confirmBut.layer.cornerRadius = 4
        
        print(UserDefaults.standard.object(forKey: CommonData.CODE))
        
        //sqlite database connection
        let fileUrl = try!
            FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("Products.sqlite")
        
        if sqlite3_open(fileUrl.path, &db) != SQLITE_OK {
            print("Error opening database")
            return
        }
        
        
        //get all products from sqlite database
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, "SELECT * FROM fruit", -1, &statement, nil) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error preparing select: \(errmsg)")
        }
        
        while sqlite3_step(statement) == SQLITE_ROW {
            let id = sqlite3_column_int64(statement, 0)
            print("id = \(id); ", terminator: "")
            var names = ""
            var price = ""
            
            if let cString = sqlite3_column_text(statement, 2) {
                let name = String(cString: cString)
                
                names = name
                print("name = \(name)")
            } else {
                print("name not found")
            }
            
            if let cStrings = sqlite3_column_text(statement, 3) {
                let names = String(cString: cStrings)
                price = names
                tot += Double(names)!
                print("name = \(names)")
            } else {
                print("name not found")
            }
            
            cart.append(Cart(name: names, price: price))
        }
        
        total.text = "R\(tot)"
        if sqlite3_finalize(statement) != SQLITE_OK {
            let errmsg = String(cString: sqlite3_errmsg(db)!)
            print("error finalizing prepared statement: \(errmsg)")
        }
        
        statement = nil
        if cart.count < 0 {
            tableview.isHidden = true
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cart.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CartCellTableViewCell
        cell.id = cart[indexPath.row].name
        cell.prodName.text = cart[indexPath.row].name
        cell.prodPrice.text = "R" + cart[indexPath.row].price!
        cell.quantity.text = "1"
        tableView.tableFooterView = UIView()
        return cell
    }
    
    
    func delete(){
        let deleteStatementStirng = "DELETE FROM BrainDump WHERE id = ?;"
        
        var deleteStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, deleteStatementStirng, -1, &deleteStatement, nil) == SQLITE_OK {
            
            sqlite3_bind_int(deleteStatement, 1, 1) //id of item to be deleted
            
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        sqlite3_finalize(deleteStatement)
        print("delete")
    }

}
