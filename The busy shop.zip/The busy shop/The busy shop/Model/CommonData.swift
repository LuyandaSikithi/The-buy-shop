//
//  CommonData.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/16.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation
public class CommonData {
    static var CODE: String{return "code_key"}
}

public class SessionService {
   
    func setSession(key:String,value:String) -> Void {
        
        UserDefaults.standard.set(value, forKey: key)
    }
    
    func getSessionString(key:String!) -> String {
        return (UserDefaults.standard.object(forKey: key) as? String)!
    }
    
    func isKeyPresentInUserDefaults(key: String) -> Bool {
        return UserDefaults.standard.object(forKey: key) != nil
    }
    
}
