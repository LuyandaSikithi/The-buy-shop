//
//  Cart.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/16.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation

struct Cart {
    var name: String?
    var price: String?
}
