//
//  productsModel.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/15.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import Foundation

struct ProductsModel {
    var id: String?
    var description: String?
    var image: String?
    var price: Double?
}
