//
//  ReceiptCellTableViewCell.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/16.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit

class ReceiptCellTableViewCell: UITableViewCell {

    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var quantity: UILabel!
    @IBOutlet weak var price: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
