//
//  CartCellTableViewCell.swift
//  The busy shop
//
//  Created by Hawk Mobile on 2019/08/16.
//  Copyright © 2019 Hawk Mobile. All rights reserved.
//

import UIKit
import SQLite3

class CartCellTableViewCell: UITableViewCell {

    @IBOutlet weak var prodName: UILabel!
    @IBOutlet weak var prodPrice: UILabel!
    @IBOutlet weak var quantity: UILabel!
    
    @IBOutlet weak var removeBut: UIButton!
    
    
    var id: String? = ""
    
    var db: OpaquePointer?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func remove(_ sender: Any) {
      
        let deleteStatementStirng = "DELETE FROM BrainDump WHERE id = ?;"
        
        var deleteStatement: OpaquePointer? = nil
        if sqlite3_prepare_v2(db, deleteStatementStirng, -1, &deleteStatement, nil) == SQLITE_OK {
            
            sqlite3_bind_int(deleteStatement, 1, 1) //id of item to be deleted
            
            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                print("Successfully deleted row.")
            } else {
                print("Could not delete row.")
            }
        } else {
            print("DELETE statement could not be prepared")
        }
        sqlite3_finalize(deleteStatement)
        print("delete")
    }
}
